let localStream;
let ws;
const localVideo = document.getElementById('localVideo');
const startButton = document.getElementById('startCall');

startButton.addEventListener('click', async () => {
    startButton.disabled = true;
    startButton.innerText = "Connecting...";

    // 1. Get access to webcam and microphone
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        localVideo.srcObject = localStream;
    } catch (err) {
        console.error("Error accessing media devices:", err);
        return;
    }

    // 2. Connect to our local Node.js WebSocket proxy
    ws = new WebSocket(`ws://${window.location.host}`);

    ws.onopen = () => {
        startButton.innerText = "Call Active";
        startButton.style.background = "#cf6679";
        
        // Start streaming video/audio frames to the server
        startStreaming(localStream);
    };

    ws.onmessage = async (event) => {
        const response = JSON.parse(event.data);
        
        // Handle incoming real-time audio chunks from Gemini
        if (response.serverContent && response.serverContent.modelTurn) {
            const parts = response.serverContent.modelTurn.parts;
            for (const part of parts) {
                if (part.inlineData && part.inlineData.mimeType.startsWith('audio/')) {
                    playAudioChunk(part.inlineData.data);
                }
            }
        }
    };
});

function startStreaming(stream) {
    const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8,opus' });
    
    mediaRecorder.ondataavailable = async (event) => {
        if (event.data.size > 0 && ws.readyState === WebSocket.OPEN) {
            // Convert data chunk to base64
            const blob = event.data;
            const reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = () => {
                const base64Data = reader.result.split(',')[1];
                
                // Formulate the Realtime API format packet
                const mediaPacket = {
                    realtimeInput: {
                        mediaChunks: [
                            {
                                mimeType: blob.type,
                                data: base64Data
                            }
                        ]
                    }
                };
                ws.send(JSON.stringify(mediaPacket));
            };
        }
    };

    // Send data chunks every 500ms for real-time fluid conversation
    mediaRecorder.start(500);
}

// Helper to queue and play incoming audio chunks seamlessly
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playAudioChunk(base64Audio) {
    const arrayBuffer = Uint8Array.from(atob(base64Audio), c => c.charCodeAt(0)).buffer;
    audioCtx.decodeAudioData(arrayBuffer, (buffer) => {
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(audioCtx.destination);
        source.start();
    });
}