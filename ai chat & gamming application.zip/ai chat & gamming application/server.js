const express = require('express');
const { WebSocketServer } = require('ws');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve frontend static files
app.use(express.static(path.join(__dirname, 'public')));

const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// Setup WebSocket server for the browser
const wss = new WebSocketServer({ server });

// Gemini Live API configuration
const GEMINI_API_KEY = process.env.AQ.Ab8RN6JD55wIjLHdsM3JpE3xVfQxTbwksAx9TMRVK-wDh9jEQA; // Ensure this is set in your environment
const GEMINI_URL = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${GEMINI_API_KEY}`;

wss.on('connection', (browserWs) => {
    console.log('Browser connected. Establishing connection to Gemini...');

    // Connect to Gemini Live API
    const geminiWs = new WebSocket(GEMINI_URL);

    geminiWs.on('open', () => {
        console.log('Connected to Gemini Live API.');
        
        // Send initial configuration to Gemini setup session
        const setupConfig = {
            setup: {
                model: "models/gemini-2.0-flash-exp", // Live API supported model
                generationConfig: {
                    responseModalities: ["AUDIO", "TEXT"] // Requesting voice back
                }
            }
        };
        geminiWs.send(JSON.stringify(setupConfig));
    });

    // Relay media data from Browser -> Gemini
    browserWs.on('message', (message) => {
        if (geminiWs.readyState === WebSocket.OPEN) {
            geminiWs.send(message);
        }
    });

    // Relay AI response from Gemini -> Browser
    geminiWs.on('message', (data) => {
        if (browserWs.readyState === WebSocket.OPEN) {
            browserWs.send(data);
        }
    });

    browserWs.on('close', () => {
        geminiWs.close();
        console.log('Browser disconnected.');
    });

    geminiWs.on('close', () => {
        browserWs.close();
        console.log('Gemini connection closed.');
    });
});



// Get all chat history (limit to last 50 messages so it loads fast)
app.get('/api/chat', async (req, res) => {
  try {
    const result = await db.query(
      'SELECT username, message, created_at FROM chat_history ORDER BY created_at ASC LIMIT 50'
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not fetch chat history" });
  }
});

// Save a new chat message
app.post('/api/chat', async (req, res) => {
  const { username, message } = req.body;
  if (!username || !message) {
    return res.status(400).json({ error: "Username and message are required" });
  }

  try {
    const result = await db.query(
      'INSERT INTO chat_history (username, message) VALUES ($1, $2) RETURNING *',
      [username, message]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not save message" });
  }
});




// Middleware (Make sure these are at the top of your server.js)
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Helps parse HTML form data

// API Endpoint to handle User Submission (Name, Age, Address)
app.post('/api/register', async (req, res) => {
  const { name, age, address } = req.body;

  // Simple validation check
  if (!name || !age || !address) {
    return res.status(400).json({ success: false, error: "All fields are required!" });
  }

  try {
    const queryText = 'INSERT INTO users (name, age, address) VALUES ($1, $2, $3) RETURNING *';
    const values = [name, parseInt(age), address];
    
    const result = await db.query(queryText, values);

    // Send back a success confirmation with the stored record
    res.status(201).json({
      success: true,
      message: "User details stored successfully inside PostgreSQL!",
      user: result.rows[0]
    });
  } catch (err) {
    console.error("Database Error:", err);
    res.status(500).json({ success: false, error: "Failed to store user details." });
  }
});