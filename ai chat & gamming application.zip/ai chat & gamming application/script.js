import { GoogleGenAI } from "@google/genai";

// CONFIGURATION: Replace with your actual Gemini API key
const GEMINI_API_KEY = new GoogleGenAI({ apiKey: process.env.AQ.Ab8RN6KKU6qqSzTu945B1Cs2C9lru9iozzaoGjxjjs8KdPc-yQ });
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

const chatHistory = document.getElementById('chatHistory');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const voiceBtn = document.getElementById('voiceBtn');
const micIcon = document.getElementById('micIcon');
const hoshinoStatus = document.getElementById('hoshinoStatus');

// Append message bubbles to screen
function appendMessage(sender, text) {
  const msgDiv = document.createElement('div');
  msgDiv.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'}`;

  const innerDiv = document.createElement('div');
  innerDiv.className = `max-w-[80%] rounded-2xl px-4 py-2.5 ${sender === 'user' ? 'bg-pink-600 text-white' : 'bg-zinc-800 text-zinc-200 border border-zinc-700'}`;
  innerDiv.innerText = text;

  msgDiv.appendChild(innerDiv);
  chatHistory.appendChild(msgDiv);
  chatHistory.scrollTop = chatHistory.scrollHeight; // Auto scroll down
}

// Call Gemini API
async function fetchAIResponse(message) {
  hoshinoStatus.innerText = "Hoshino is thinking...";
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: `You are Hoshino, a helpful anime companion. Keep answers relatively short. ${message}` }] }]
      })
    });
    const data = await response.json();
    const text = data.candidates[0].content.parts[0].text;
    appendMessage('ai', text);
  } catch (error) {
    console.error(error);
    appendMessage('ai', "Sorry, my brain caught a glitch. Try again!");
  } finally {
    hoshinoStatus.innerText = "";
  }
}

function handleSend() {
  const text = userInput.value.trim();
  if (!text) return;
  appendMessage('user', text);
  userInput.value = '';
  fetchAIResponse(text);
}

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSend(); });

// Native Web Speech API for Voice Input
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.lang = 'en-US';

  voiceBtn.addEventListener('click', () => {
    recognition.start();
    micIcon.className = "fa-solid fa-microphone-lines text-pink-500 animate-pulse";
    hoshinoStatus.innerText = "Listening...";
  });

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    micIcon.className = "fa-solid fa-microphone";
    hoshinoStatus.innerText = "";
    handleSend(); // Auto-send transcripted speech
  };

  recognition.onerror = () => {
    micIcon.className = "fa-solid fa-microphone";
    hoshinoStatus.innerText = "Voice Error";
  };

  recognition.onend = () => {
    micIcon.className = "fa-solid fa-microphone";
  };
} else {
  voiceBtn.style.display = 'none'; // Hide if browser doesn't support speech-to-text
}
